import pandas as pd
import re

df = pd.read_csv('data/dataset_1.csv')
print(df.head())

positiveFileContent = "["
negativeFileContent = "["

for index, row in df.iterrows():
    # print(row['review'], row['sentiment'])
    cleanRow = row['review'].replace(".", "")
    cleanRow = cleanRow.replace("'", "")
    cleanRow = cleanRow.replace('"', "")

    # print(re.sub(r'[^A-Za-z0-9 ]+', '', cleanRow))
    cleanRow = re.sub(r'[^A-Za-z0-9 ]+', '', cleanRow)

    if row['sentiment'] == 'positive':
        positiveFileContent += "["
        words = cleanRow.split(" ")
        for i in range(len(words)):
            positiveFileContent += '"'+words[i]+'"'
            if i < len(words):
                positiveFileContent += ','
        positiveFileContent += "],"

    if row['sentiment'] == 'negative':
        negativeFileContent += "["
        words = cleanRow.split(" ")
        for i in range(len(words)):
            negativeFileContent += '"'+words[i]+'"'
            if i < len(words):
                negativeFileContent += ','
        negativeFileContent += "],"

positiveFileContent += ']'
negativeFileContent += ']'

positiveFileContent = positiveFileContent.replace(',]', ']')
negativeFileContent = negativeFileContent.replace(',]', ']')

# print(positiveFileContent)
# print(negativeFileContent)

text_file = open("positive.json", "w")
n = text_file.write(positiveFileContent)
text_file.close()

text_file = open("negative.json", "w")
n = text_file.write(negativeFileContent)
text_file.close()
